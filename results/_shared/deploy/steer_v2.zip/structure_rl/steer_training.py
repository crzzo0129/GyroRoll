"""Steering v2 sampling and reflection utilities, independent of MJLab imports."""
import torch

PROFILE = 'steer_v2'
OBS_REFLECTION = (1, -1, 1, -1, 1, -1, 1, -1, 1, 1, -1, -1, 1, -1, 1, -1)
ACTION_REFLECTION = (1, -1)


def sample_commands(actual_forward):
    """20% stop, 20% each straight direction, 15% each turn, 10% reversal."""
    n = len(actual_forward)
    device = actual_forward.device
    category = torch.bucketize(torch.rand(n, device=device),
                              torch.tensor([.2, .4, .6, .75, .9], device=device))
    magnitude = torch.empty(n, device=device).uniform_(.3, 1.)
    sign = torch.where(torch.rand(n, device=device) < .5, -1., 1.)
    speed = magnitude * sign
    speed = torch.where(category == 1, magnitude, speed)
    speed = torch.where(category == 2, -magnitude, speed)
    # When already moving, explicitly request a change of direction.
    reverse = torch.where(actual_forward.abs() > .15, -actual_forward.sign(), sign)
    speed = torch.where(category == 5, magnitude * reverse, speed)
    yaw = torch.empty(n, device=device).uniform_(.1, .3)
    yaw = torch.where(category == 3, yaw, torch.where(category == 4, -yaw, 0.))
    command = torch.stack((speed, torch.zeros_like(speed), yaw), dim=1)
    command[category == 0] = 0.
    return command, category


def sample_initial_speed(n, device):
    """Half from rest, one quarter forward, one quarter reverse."""
    choice = torch.rand(n, device=device)
    magnitude = torch.empty(n, device=device).uniform_(.3, .9)
    return torch.where(choice < .5, 0., torch.where(choice < .75, magnitude, -magnitude))


def mirror(obs=None, actions=None, env=None):
    """Original + sagittal reflection; consumes raw observations before normalization."""
    if obs is not None:
        reflected = obs.clone()
        for key in ('actor', 'critic'):
            if obs[key].shape[-1] != len(OBS_REFLECTION):
                raise ValueError('Reflection requires the 16D raked-steering observation contract')
            reflected[key] = obs[key] * obs[key].new_tensor(OBS_REFLECTION)
        obs = torch.cat((obs, reflected), dim=0)
    if actions is not None:
        actions = torch.cat((actions, actions * actions.new_tensor(ACTION_REFLECTION)), dim=0)
    return obs, actions


def reset_exploration(actor, std=.08):
    distribution = actor.distribution
    fraction = (std - distribution.min_std) / (distribution.max_std - distribution.min_std)
    if not 0 < fraction.item() < 1:
        raise ValueError('Exploration reset must lie inside checkpoint std bounds')
    with torch.no_grad():
        distribution.std_logit.fill_(torch.logit(fraction).item())
